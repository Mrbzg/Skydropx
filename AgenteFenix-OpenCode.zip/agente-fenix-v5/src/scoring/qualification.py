"""
Calificación BANT y MEDDIC para leads — 100% local, zero-deps, $0.

Complementa el scoring existente (DATA_SCORE / SKYDROPX_SCORE / SALES_PRIORITY /
ICP) con dos metodologías de ventas estándar:

- BANT   : Budget, Authority, Need, Timeline
- MEDDIC : Metrics, Economic buyer, Decision criteria, Decision process,
           Identify pain, Champion

La idea NO es inventar datos, sino INFERIR señales a partir de lo que el pipeline
ya descubrió (giro, tamaño, intención de envíos, paqueterías mencionadas, presencia
digital, cargo del contacto, etc.). Cada dimensión devuelve:
  - score 0-100
  - evidencia (qué señal la disparó)
  - confianza (alta/media/baja) según cuántas señales reales había

Todo es heurístico y transparente: si no hay evidencia, el score es bajo y la
confianza es "baja" (no se rellena con humo).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Utilidades de extracción de señales (sin inventar nada)
# ---------------------------------------------------------------------------

_BUYING_INTENT = [
    "cotiza", "cotización", "cotizacion", "proveedor", "licitación", "licitacion",
    "necesitamos", "buscamos", "requerimos", "presupuesto", "rfq", "rfp",
    "convocatoria", "solicitud de propuesta", "tarifas", "envíos a toda",
    "envios a toda", "paquetería", "paqueteria", "fulfillment", "logística",
    "logistica", "mayoreo", "distribuidor", "importador",
]

_AUTHORITY_TITLES = [
    "ceo", "founder", "fundador", "fundadora", "director", "directora", "dueño",
    "dueña", "owner", "propietario", "gerente", "gerencia", "head", "vp",
    "vicepresidente", "socio", "socia", "coordinador de compras", "comprador",
    "encargado", "responsable", "manager",
]

_URGENCY = [
    "urgente", "inmediato", "hoy", "esta semana", "ya", "cuanto antes",
    "lanzamiento", "temporada", "buen fin", "navidad", "black friday",
    "hot sale", "campaña", "campana", "evento",
]


def _text_blob(lead: dict[str, Any]) -> str:
    """Concatena los campos textuales del lead para buscar señales."""
    parts: list[str] = []
    for k in ("nombre", "empresa", "giro", "cargo", "nombre_persona",
              "descripcion", "value_proposition", "soluciones", "sitio_web"):
        v = lead.get(k)
        if v:
            parts.append(str(v))
    md = lead.get("metadata") or {}
    for k in ("envios_intent", "plataforma_detectada", "descripcion", "snippet"):
        v = md.get(k)
        if v:
            parts.append(str(v))
    paq = md.get("paqueterias_mencionadas") or lead.get("paqueterias_mencionadas")
    if paq:
        parts.append(" ".join(map(str, paq)) if isinstance(paq, list) else str(paq))
    return " | ".join(parts).lower()


def _match_any(text: str, patterns: list[str]) -> list[str]:
    return [p for p in patterns if p in text]


def _has_envios(lead: dict[str, Any]) -> bool:
    md = lead.get("metadata") or {}
    return bool(lead.get("envios_intent") or lead.get("_envios_intent")
                or md.get("envios_intent"))


def _competencia(lead: dict[str, Any]) -> list[str]:
    md = lead.get("metadata") or {}
    paq = set(md.get("paqueterias_mencionadas") or []) - {"skydropx"}
    return sorted(paq)


def _confidence(n_signals: int) -> str:
    if n_signals >= 3:
        return "alta"
    if n_signals >= 1:
        return "media"
    return "baja"


# ---------------------------------------------------------------------------
# Estructuras de salida
# ---------------------------------------------------------------------------

@dataclass
class Dimension:
    name: str
    score: int = 0
    confidence: str = "baja"
    evidence: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "score": self.score,
            "confidence": self.confidence,
            "evidence": self.evidence,
        }


# ---------------------------------------------------------------------------
# BANT
# ---------------------------------------------------------------------------

def bant_analyze(lead: dict[str, Any]) -> dict[str, Any]:
    """Budget, Authority, Need, Timeline — heurístico sobre datos reales."""
    text = _text_blob(lead)
    tamano = (lead.get("tamano") or "").strip().lower()
    has_envios = _has_envios(lead)
    comp = _competencia(lead)

    # --- Budget: inferido por tamaño + actividad de envíos (no es dato financiero real) ---
    budget = Dimension("budget")
    if tamano in ("mediana", "grande"):
        budget.score = 80 if tamano == "grande" else 65
        budget.evidence.append(f"tamaño={tamano} (mayor capacidad de gasto)")
    elif tamano in ("pequeña", "pequena"):
        budget.score = 45
        budget.evidence.append("tamaño=pequeña")
    elif tamano == "micro":
        budget.score = 30
        budget.evidence.append("tamaño=micro")
    if comp:
        budget.score = min(100, budget.score + 20)
        budget.evidence.append(f"ya invierte en paquetería: {', '.join(comp)}")
    budget.confidence = _confidence(len(budget.evidence))

    # --- Authority: ¿el contacto es decisor? ---
    authority = Dimension("authority")
    cargo = (lead.get("cargo") or lead.get("nombre_persona") or "").lower()
    titles = _match_any(cargo + " " + text, _AUTHORITY_TITLES)
    if titles:
        # cargos ejecutivos pesan más
        top = any(t in titles for t in ("ceo", "founder", "fundador", "fundadora",
                                        "director", "directora", "dueño", "dueña",
                                        "owner", "propietario", "socio", "socia"))
        authority.score = 85 if top else 55
        authority.evidence.append(f"cargo decisor: {', '.join(sorted(set(titles)))}")
    elif lead.get("nombre_persona"):
        authority.score = 35
        authority.evidence.append("hay contacto persona, cargo no confirmado")
    authority.confidence = _confidence(len(authority.evidence))

    # --- Need: ¿necesita logística/envíos? (núcleo de Skydropx) ---
    need = Dimension("need")
    intent_hits = _match_any(text, _BUYING_INTENT)
    if has_envios:
        need.score = 80
        need.evidence.append("intención de envíos detectada")
    if comp:
        need.score = max(need.score, 75)
        need.evidence.append(f"ya envía con competencia: {', '.join(comp)}")
    if intent_hits:
        need.score = max(need.score, 60)
        need.evidence.append(f"señales de compra: {', '.join(intent_hits[:3])}")
    if not need.evidence:
        # giro de ecommerce/retail implica necesidad latente
        giro = (lead.get("giro") or "").lower()
        if any(g in giro for g in ("comercio", "tienda", "venta", "boutique",
                                    "ecommerce", "e-commerce", "mayorista")):
            need.score = 45
            need.evidence.append(f"giro con necesidad latente de envíos: {giro[:40]}")
    need.confidence = _confidence(len(need.evidence))

    # --- Timeline: ¿hay urgencia/temporalidad? ---
    timeline = Dimension("timeline")
    urg = _match_any(text, _URGENCY)
    if urg:
        timeline.score = 70
        timeline.evidence.append(f"señales de urgencia: {', '.join(urg[:3])}")
    elif has_envios or comp:
        timeline.score = 50
        timeline.evidence.append("operación de envíos activa (necesidad continua)")
    timeline.confidence = _confidence(len(timeline.evidence))

    dims = {d.name: d for d in (budget, authority, need, timeline)}
    total = round(sum(d.score for d in dims.values()) / 4)
    qualified = total >= 60 and need.score >= 50  # need es condición necesaria

    return {
        "framework": "BANT",
        "total_score": total,
        "qualified": qualified,
        "label": _bant_label(total),
        "dimensions": {k: v.to_dict() for k, v in dims.items()},
        "note": "Scores heurísticos inferidos de datos públicos reales. No son "
                "datos financieros confirmados; validar con el prospecto.",
    }


def _bant_label(total: int) -> str:
    if total >= 75:
        return "ALTAMENTE_CALIFICADO"
    if total >= 60:
        return "CALIFICADO"
    if total >= 40:
        return "A_NUTRIR"
    return "NO_CALIFICADO"


# ---------------------------------------------------------------------------
# MEDDIC
# ---------------------------------------------------------------------------

def meddic_score(lead: dict[str, Any]) -> dict[str, Any]:
    """Metrics, Economic buyer, Decision criteria, Decision process,
    Identify pain, Champion."""
    text = _text_blob(lead)
    has_envios = _has_envios(lead)
    comp = _competencia(lead)
    tamano = (lead.get("tamano") or "").strip().lower()
    cargo = (lead.get("cargo") or lead.get("nombre_persona") or "").lower()

    # Metrics — ¿hay magnitud/volumen inferible?
    metrics = Dimension("metrics")
    if tamano in ("mediana", "grande"):
        metrics.score = 70
        metrics.evidence.append(f"tamaño={tamano} sugiere volumen relevante")
    if comp:
        metrics.score = max(metrics.score, 65)
        metrics.evidence.append("volumen de envíos activo (usa paquetería)")
    metrics.confidence = _confidence(len(metrics.evidence))

    # Economic buyer — ¿identificamos al decisor económico?
    eco = Dimension("economic_buyer")
    titles = _match_any(cargo, _AUTHORITY_TITLES)
    if any(t in titles for t in ("ceo", "founder", "fundador", "fundadora",
                                 "director", "directora", "dueño", "dueña",
                                 "owner", "propietario", "socio", "socia")):
        eco.score = 80
        eco.evidence.append(f"posible comprador económico: {cargo[:40]}")
    elif titles:
        eco.score = 45
        eco.evidence.append(f"contacto con influencia: {cargo[:40]}")
    eco.confidence = _confidence(len(eco.evidence))

    # Decision criteria — ¿qué valoraría? (inferido del pain logístico)
    dc = Dimension("decision_criteria")
    if comp:
        dc.score = 70
        dc.evidence.append(f"compara contra: {', '.join(comp)} (precio/cobertura/tracking)")
    elif has_envios:
        dc.score = 55
        dc.evidence.append("busca solución de envíos (cobertura nacional, tarifas)")
    dc.confidence = _confidence(len(dc.evidence))

    # Decision process — presencia digital ⇒ procesos más formales
    dp = Dimension("decision_process")
    has_web = bool(lead.get("sitio_web"))
    plataforma = (lead.get("metadata") or {}).get("plataforma_detectada")
    if has_web and tamano in ("mediana", "grande"):
        dp.score = 60
        dp.evidence.append("empresa formal con web (proceso de compra estructurado)")
    elif has_web or plataforma:
        dp.score = 40
        dp.evidence.append("presencia digital (proceso semi-formal)")
    dp.confidence = _confidence(len(dp.evidence))

    # Identify pain — el dolor logístico es el core
    pain = Dimension("identify_pain")
    if comp:
        pain.score = 80
        pain.evidence.append("dolor real: ya paga envíos (oportunidad de mejor tarifa/servicio)")
    elif has_envios:
        pain.score = 70
        pain.evidence.append("necesidad de envíos confirmada")
    else:
        giro = (lead.get("giro") or "").lower()
        if any(g in giro for g in ("comercio", "tienda", "venta", "boutique",
                                    "ecommerce", "mayorista")):
            pain.score = 45
            pain.evidence.append("dolor latente por giro comercial")
    pain.confidence = _confidence(len(pain.evidence))

    # Champion — ¿tenemos un contacto humano que pueda abanderar?
    champ = Dimension("champion")
    if lead.get("nombre_persona"):
        champ.score = 50 if not titles else 70
        champ.evidence.append(f"contacto identificado: {lead.get('nombre_persona')}")
    champ.confidence = _confidence(len(champ.evidence))

    dims = {d.name: d for d in (metrics, eco, dc, dp, pain, champ)}
    total = round(sum(d.score for d in dims.values()) / 6)

    # Gaps = dimensiones con score bajo (qué falta investigar/preguntar)
    gaps = [name for name, d in dims.items() if d.score < 40]

    return {
        "framework": "MEDDIC",
        "total_score": total,
        "label": _meddic_label(total),
        "dimensions": {k: v.to_dict() for k, v in dims.items()},
        "gaps": gaps,
        "next_questions": _meddic_questions(gaps),
        "note": "Scores heurísticos sobre datos públicos. Los 'gaps' indican qué "
                "confirmar con el prospecto antes de avanzar el deal.",
    }


def _meddic_label(total: int) -> str:
    if total >= 70:
        return "DEAL_FUERTE"
    if total >= 50:
        return "DEAL_VIABLE"
    if total >= 30:
        return "DEAL_TEMPRANO"
    return "DEAL_DEBIL"


_MEDDIC_Q = {
    "metrics": "¿Cuántos envíos mensuales manejan hoy?",
    "economic_buyer": "¿Quién aprueba el presupuesto de logística?",
    "decision_criteria": "¿Qué es lo más importante: tarifa, cobertura o tracking?",
    "decision_process": "¿Cómo evalúan y deciden un nuevo proveedor de envíos?",
    "identify_pain": "¿Qué problema tienen hoy con su paquetería actual?",
    "champion": "¿Quién dentro del equipo impulsaría el cambio a Skydropx?",
}


def _meddic_questions(gaps: list[str]) -> list[str]:
    return [_MEDDIC_Q[g] for g in gaps if g in _MEDDIC_Q]


def qualify_lead(lead: dict[str, Any]) -> dict[str, Any]:
    """Conveniencia: corre BANT + MEDDIC juntos."""
    return {
        "bant": bant_analyze(lead),
        "meddic": meddic_score(lead),
    }


__all__ = ["bant_analyze", "meddic_score", "qualify_lead", "Dimension"]
