"""
Rutas amigables para el usuario final (no técnico).

El problema: con la instalación "a prueba de borrado", el proyecto vive en
~/.config/opencode/agente-fenix-app/ y los exports caen en .../output/, una
carpeta que un usuario inexperto JAMÁS encontrará.

Solución: resolver carpetas conocidas y fáciles (Escritorio, Descargas,
Documentos) en Windows/Mac/Linux, incluyendo nombres en español. Así el agente
puede guardar los leads donde el usuario sí los va a ver.

Zero-deps. Todo con stdlib.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Subcarpeta donde guardamos los leads para no ensuciar el Escritorio/Descargas.
LEADS_SUBFOLDER = "Leads-Fenix"


def _home() -> Path:
    return Path.home()


def _first_existing(candidates: list[Path]) -> Path | None:
    for c in candidates:
        try:
            if c.is_dir():
                return c
        except Exception:
            continue
    return None


def desktop_dir() -> Path | None:
    """Escritorio del usuario (Windows/Mac/Linux, ES/EN)."""
    h = _home()
    cands = [h / "Desktop", h / "Escritorio"]
    # Windows: a veces el Escritorio está bajo OneDrive
    onedrive = os.environ.get("OneDrive") or os.environ.get("OneDriveConsumer")
    if onedrive:
        cands += [Path(onedrive) / "Desktop", Path(onedrive) / "Escritorio"]
    return _first_existing(cands)


def downloads_dir() -> Path | None:
    """Carpeta de Descargas del usuario (ES/EN)."""
    h = _home()
    cands = [h / "Downloads", h / "Descargas"]
    onedrive = os.environ.get("OneDrive") or os.environ.get("OneDriveConsumer")
    if onedrive:
        cands += [Path(onedrive) / "Downloads", Path(onedrive) / "Descargas"]
    return _first_existing(cands)


def documents_dir() -> Path | None:
    """Carpeta de Documentos del usuario (ES/EN)."""
    h = _home()
    cands = [h / "Documents", h / "Documentos"]
    onedrive = os.environ.get("OneDrive") or os.environ.get("OneDriveConsumer")
    if onedrive:
        cands += [Path(onedrive) / "Documents", Path(onedrive) / "Documentos"]
    return _first_existing(cands)


def default_leads_dir() -> Path:
    """
    Mejor carpeta por defecto para que el usuario ENCUENTRE sus leads.
    Orden de preferencia: Escritorio → Descargas → Documentos → home.
    Devuelve .../<carpeta>/Leads-Fenix (la crea al guardar, no aquí).
    """
    base = desktop_dir() or downloads_dir() or documents_dir() or _home()
    return base / LEADS_SUBFOLDER


def resolve_output_dir(choice: str | None = None) -> Path:
    """
    Traduce la elección del usuario a una ruta real.

    choice puede ser:
      - None / "" / "default"          → Escritorio/Leads-Fenix (recomendado)
      - "escritorio" / "desktop"        → Escritorio/Leads-Fenix
      - "descargas" / "downloads"       → Descargas/Leads-Fenix
      - "documentos" / "documents"      → Documentos/Leads-Fenix
      - "aqui" / "proyecto" / "output"  → carpeta output/ del proyecto (técnico)
      - una RUTA absoluta o ~/...        → esa ruta tal cual
    """
    if not choice or choice.strip().lower() in ("default", "predeterminado", "recomendado"):
        return default_leads_dir()

    c = choice.strip()
    low = c.lower()

    mapping = {
        "escritorio": desktop_dir, "desktop": desktop_dir,
        "descargas": downloads_dir, "downloads": downloads_dir,
        "documentos": documents_dir, "documents": documents_dir,
    }
    if low in mapping:
        base = mapping[low]() or _home()
        return base / LEADS_SUBFOLDER

    if low in ("aqui", "aquí", "proyecto", "output", "."):
        return Path("output")

    # Asumir que es una ruta dada por el usuario (~ se expande)
    p = Path(os.path.expanduser(c))
    return p


def describe_location(path: Path) -> str:
    """Frase amigable para decirle al usuario dónde quedó el archivo."""
    p = path.resolve()
    parts_low = [s.lower() for s in p.parts]
    if "leads-fenix" in parts_low:
        if any(x in parts_low for x in ("desktop", "escritorio")):
            return f"en tu Escritorio, carpeta '{LEADS_SUBFOLDER}'"
        if any(x in parts_low for x in ("downloads", "descargas")):
            return f"en tus Descargas, carpeta '{LEADS_SUBFOLDER}'"
        if any(x in parts_low for x in ("documents", "documentos")):
            return f"en tus Documentos, carpeta '{LEADS_SUBFOLDER}'"
    return f"en: {p}"


def open_in_file_manager(path: Path) -> bool:
    """Abre la carpeta en el explorador de archivos del sistema. Best-effort."""
    p = path.resolve()
    target = str(p if p.is_dir() else p.parent)
    try:
        if sys.platform.startswith("win"):
            os.startfile(target)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            import subprocess
            subprocess.run(["open", target], check=False)
        else:
            import subprocess
            subprocess.run(["xdg-open", target], check=False)
        return True
    except Exception:
        return False


__all__ = [
    "resolve_output_dir", "default_leads_dir", "describe_location",
    "open_in_file_manager", "desktop_dir", "downloads_dir", "documents_dir",
    "LEADS_SUBFOLDER",
]
