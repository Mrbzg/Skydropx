"""
Caché local con TTL — evita repetir búsquedas/lookups idénticos. Zero-deps, $0.

Persistente en disco (JSON) para que el caché sobreviva entre corridas y entre
procesos (el MCP server y la CLI comparten el mismo archivo). Pensado para:
  - resultados de dorks/búsquedas web (TTL corto, ~1h)
  - validaciones de email/teléfono (TTL medio)
  - conteos DENUE (TTL largo)

No cachea PII sensible más de lo necesario y respeta un TTL configurable.
Es thread-safe a nivel de proceso con un lock simple.
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from pathlib import Path
from typing import Any, Callable

_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_DEFAULT_PATH = _PROJECT_ROOT / "data" / "cache.json"

# TTLs por defecto (segundos) por "namespace".
DEFAULT_TTL = {
    "search": 3600,        # 1 hora
    "dorks": 3600,
    "verify_email": 86400,   # 1 día
    "verify_phone": 604800,  # 1 semana (el formato no cambia)
    "denue_count": 604800,   # 1 semana
    "tech_stack": 86400,
    "default": 3600,
}

_lock = threading.Lock()


class TTLCache:
    def __init__(self, path: Path | None = None):
        self.path = path or _DEFAULT_PATH
        self._data: dict[str, dict] = {}
        self._loaded = False

    # ---------- persistencia ----------
    def _load(self) -> None:
        if self._loaded:
            return
        try:
            if self.path.exists():
                self._data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            self._data = {}
        self._loaded = True

    def _save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(
                json.dumps(self._data, ensure_ascii=False, default=str),
                encoding="utf-8",
            )
        except Exception:
            pass

    # ---------- claves ----------
    @staticmethod
    def make_key(namespace: str, payload: Any) -> str:
        raw = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str)
        h = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
        return f"{namespace}:{h}"

    # ---------- API ----------
    def get(self, key: str) -> Any | None:
        with _lock:
            self._load()
            entry = self._data.get(key)
            if not entry:
                return None
            if entry.get("expires_at", 0) < time.time():
                # expirado: limpiar
                self._data.pop(key, None)
                self._save()
                return None
            return entry.get("value")

    def set(self, key: str, value: Any, ttl: int | None = None,
            namespace: str = "default") -> None:
        if ttl is None:
            ttl = DEFAULT_TTL.get(namespace, DEFAULT_TTL["default"])
        with _lock:
            self._load()
            self._data[key] = {
                "value": value,
                "expires_at": time.time() + ttl,
                "stored_at": time.time(),
                "namespace": namespace,
            }
            self._save()

    def get_or_set(self, namespace: str, payload: Any,
                   producer: Callable[[], Any], ttl: int | None = None) -> Any:
        """Devuelve del caché si existe y es fresco; si no, ejecuta producer()."""
        key = self.make_key(namespace, payload)
        cached = self.get(key)
        if cached is not None:
            return {"_cache": "hit", **cached} if isinstance(cached, dict) else cached
        value = producer()
        self.set(key, value, ttl=ttl, namespace=namespace)
        return {"_cache": "miss", **value} if isinstance(value, dict) else value

    def purge_expired(self) -> int:
        with _lock:
            self._load()
            now = time.time()
            expired = [k for k, v in self._data.items()
                       if v.get("expires_at", 0) < now]
            for k in expired:
                self._data.pop(k, None)
            if expired:
                self._save()
            return len(expired)

    def clear(self, namespace: str | None = None) -> int:
        with _lock:
            self._load()
            if namespace is None:
                n = len(self._data)
                self._data = {}
            else:
                keys = [k for k, v in self._data.items()
                        if v.get("namespace") == namespace]
                for k in keys:
                    self._data.pop(k, None)
                n = len(keys)
            self._save()
            return n

    def stats(self) -> dict:
        with _lock:
            self._load()
            now = time.time()
            by_ns: dict[str, int] = {}
            fresh = expired = 0
            for v in self._data.values():
                ns = v.get("namespace", "default")
                by_ns[ns] = by_ns.get(ns, 0) + 1
                if v.get("expires_at", 0) < now:
                    expired += 1
                else:
                    fresh += 1
            return {
                "total_entries": len(self._data),
                "fresh": fresh,
                "expired": expired,
                "by_namespace": by_ns,
                "path": str(self.path),
            }


# Singleton de proceso
_default_cache: TTLCache | None = None


def get_cache() -> TTLCache:
    global _default_cache
    if _default_cache is None:
        _default_cache = TTLCache()
    return _default_cache


__all__ = ["TTLCache", "get_cache", "DEFAULT_TTL"]
