"""
Attribution / Provenance — saber qué FUENTE aportó cada dato de un lead.

Útil para auditoría LFPDPPP y para confiar en los datos: cada campo (email,
teléfono, etc.) queda etiquetado con la fuente que lo aportó y una confianza
basada en la confiabilidad histórica de esa fuente.

Zero-deps, $0. Reconstruye la atribución a partir de los `_raw_records` que el
pipeline ya guarda en cada Lead (cada RawRecord trae su `source`).
"""
from __future__ import annotations

from typing import Any

# Confiabilidad base por fuente (0.0–1.0). Coincide con references/fuentes.md.
SOURCE_CONFIDENCE = {
    "denue": 0.95,
    "camaras": 0.88,
    "mercadolibre": 0.85,
    "google_maps": 0.80,
    "dorks": 0.75,
    "dorks_shopify": 0.78,
    "social_shops": 0.72,
    "website": 0.85,
    "sitemap": 0.80,
    "re_enrich": 0.65,
    "email_inferencer": 0.55,
    "domain_finder": 0.60,
    "import": 0.50,
    "unknown": 0.40,
}

# Campos a los que les rastreamos procedencia.
TRACKED_FIELDS = [
    "empresa", "nombre_persona", "rfc", "email", "telefono", "whatsapp",
    "sitio_web", "instagram", "linkedin", "facebook", "direccion",
    "municipio", "estado", "scian", "tamano",
]

# Alias entre nombres de campo de RawRecord y Lead.
_ALIASES = {
    "nombre": ["empresa", "nombre_comercial"],
    "ubicacion": ["municipio"],
    "giro": ["giro_descripcion"],
}


def _source_confidence(source: str) -> float:
    if not source:
        return SOURCE_CONFIDENCE["unknown"]
    s = source.lower()
    if s in SOURCE_CONFIDENCE:
        return SOURCE_CONFIDENCE[s]
    # match parcial (p.ej. 'dorks_shopify_mx' -> 'dorks')
    for k, v in SOURCE_CONFIDENCE.items():
        if k in s:
            return v
    return SOURCE_CONFIDENCE["unknown"]


def _value_of(record: dict[str, Any], field: str) -> Any:
    """Obtiene el valor de un campo en un raw record, considerando alias."""
    if record.get(field):
        return record[field]
    for alias in _ALIASES.get(field, []):
        if record.get(alias):
            return record[alias]
    return None


def build_provenance(raw_records: list[dict[str, Any]],
                     final_values: dict[str, Any] | None = None) -> dict[str, Any]:
    """
    Construye un mapa de procedencia por campo.

    Args:
        raw_records: lista de dicts de RawRecord (cada uno con su 'source').
        final_values: opcional, los valores finales del lead, para atribuir
                      exactamente la fuente cuyo valor coincide con el final.

    Returns:
        {
          "fields": {
             "email": {"value": "...", "provider": "denue", "confidence": 0.95,
                        "providers_seen": ["denue","website"]},
             ...
          },
          "sources_used": ["denue","website"],
          "overall_confidence": 0.88
        }
    """
    final_values = final_values or {}
    fields_out: dict[str, Any] = {}
    sources_used: set[str] = set()

    for field in TRACKED_FIELDS:
        candidates: list[tuple[str, Any, float]] = []  # (source, value, conf)
        for rec in raw_records:
            src = (rec.get("source") or "unknown")
            val = _value_of(rec, field)
            if val:
                candidates.append((src, val, _source_confidence(src)))
                sources_used.add(src)
        if not candidates:
            continue

        providers_seen = sorted({c[0] for c in candidates})
        final_val = final_values.get(field)

        chosen = None
        if final_val:
            # buscar la fuente cuyo valor coincide con el final (mejor atribución)
            for src, val, conf in sorted(candidates, key=lambda c: -c[2]):
                if str(val).strip().lower() == str(final_val).strip().lower():
                    chosen = (src, val, conf)
                    break
        if chosen is None:
            # fallback: la fuente de mayor confianza
            chosen = max(candidates, key=lambda c: c[2])

        fields_out[field] = {
            "value": chosen[1],
            "provider": chosen[0],
            "confidence": round(chosen[2], 2),
            "providers_seen": providers_seen,
        }

    overall = (round(sum(f["confidence"] for f in fields_out.values())
                     / len(fields_out), 2) if fields_out else 0.0)

    return {
        "fields": fields_out,
        "sources_used": sorted(sources_used),
        "overall_confidence": overall,
        "n_fields_attributed": len(fields_out),
    }


def provenance_for_lead(lead: dict[str, Any]) -> dict[str, Any]:
    """
    Conveniencia: recibe un lead (dict, p.ej. de db_companies o export) y arma
    su procedencia. Usa `_raw_records` si está; si no, atribuye todo a `fuentes`.
    """
    raw = lead.get("_raw_records") or []
    if not raw:
        # Sin raw records: atribuir todos los campos presentes a 'fuentes'
        fuentes = lead.get("fuentes") or "unknown"
        primary = fuentes.split(",")[0].strip() if fuentes else "unknown"
        raw = [{**lead, "source": primary}]
    return build_provenance(raw, final_values=lead)


__all__ = ["build_provenance", "provenance_for_lead", "SOURCE_CONFIDENCE"]
