"""Tests para las 3 mejoras: BANT/MEDDIC, provenance y caché TTL."""
import tempfile
import time
from pathlib import Path

import pytest

from src.scoring.qualification import bant_analyze, meddic_score, qualify_lead
from src.core.provenance import build_provenance, provenance_for_lead
from src.core.cache import TTLCache


# ---------------- BANT / MEDDIC ----------------

HOT_LEAD = {
    "empresa": "Boutique Regia",
    "nombre_persona": "Ana López",
    "cargo": "Directora Comercial",
    "tamano": "Mediana",
    "email": "ventas@boutiqueregia.com.mx",
    "telefono": "+528112345678",
    "sitio_web": "https://boutiqueregia.com.mx",
    "giro": "comercio al por menor de ropa",
    "metadata": {
        "envios_intent": True,
        "paqueterias_mencionadas": ["estafeta", "dhl"],
        "plataforma_detectada": "shopify",
    },
}

COLD_LEAD = {"empresa": "Tiendita X", "giro": "comercio"}


class TestBANT:
    def test_hot_lead_is_qualified(self):
        r = bant_analyze(HOT_LEAD)
        assert r["framework"] == "BANT"
        assert r["total_score"] >= 60
        assert r["qualified"] is True
        assert r["label"] in ("CALIFICADO", "ALTAMENTE_CALIFICADO")

    def test_cold_lead_not_qualified(self):
        r = bant_analyze(COLD_LEAD)
        assert r["qualified"] is False
        assert r["total_score"] < 60

    def test_dimensions_present(self):
        r = bant_analyze(HOT_LEAD)
        for dim in ("budget", "authority", "need", "timeline"):
            assert dim in r["dimensions"]
            assert "confidence" in r["dimensions"][dim]

    def test_no_fake_data_low_confidence(self):
        r = bant_analyze(COLD_LEAD)
        # Sin evidencia => confianza baja en need
        assert r["dimensions"]["need"]["confidence"] in ("baja", "media")

    def test_competencia_boosts_need(self):
        r = bant_analyze(HOT_LEAD)
        assert r["dimensions"]["need"]["score"] >= 70


class TestMEDDIC:
    def test_hot_lead_strong_deal(self):
        r = meddic_score(HOT_LEAD)
        assert r["framework"] == "MEDDIC"
        assert r["total_score"] >= 50
        assert len(r["dimensions"]) == 6

    def test_cold_lead_has_gaps_and_questions(self):
        r = meddic_score(COLD_LEAD)
        assert len(r["gaps"]) > 0
        assert len(r["next_questions"]) > 0

    def test_identify_pain_with_competencia(self):
        r = meddic_score(HOT_LEAD)
        assert r["dimensions"]["identify_pain"]["score"] >= 70


class TestQualifyLead:
    def test_both_frameworks(self):
        r = qualify_lead(HOT_LEAD)
        assert "bant" in r and "meddic" in r


# ---------------- Provenance ----------------

class TestProvenance:
    def test_build_from_raw_records(self):
        raw = [
            {"source": "denue", "empresa": "Boutique Regia", "telefono": "+528112345678"},
            {"source": "website", "email": "ventas@boutiqueregia.com.mx"},
        ]
        p = build_provenance(raw, final_values={
            "email": "ventas@boutiqueregia.com.mx", "telefono": "+528112345678"})
        assert p["fields"]["telefono"]["provider"] == "denue"
        assert p["fields"]["email"]["provider"] == "website"
        assert 0 < p["overall_confidence"] <= 1.0
        assert set(p["sources_used"]) == {"denue", "website"}

    def test_denue_higher_confidence_than_dorks(self):
        raw = [{"source": "denue", "telefono": "5511111111"},
               {"source": "dorks", "telefono": "5522222222"}]
        p = build_provenance(raw)
        # gana denue por confianza
        assert p["fields"]["telefono"]["provider"] == "denue"

    def test_lead_without_raw_records(self):
        lead = {"email": "x@y.com", "fuentes": "denue"}
        p = provenance_for_lead(lead)
        assert "email" in p["fields"]
        assert p["fields"]["email"]["provider"] == "denue"


# ---------------- Cache TTL ----------------

@pytest.fixture
def temp_cache():
    path = Path(tempfile.mktemp(suffix=".json"))
    yield TTLCache(path=path)
    try:
        path.unlink()
    except OSError:
        pass


class TestCache:
    def test_get_or_set_caches(self, temp_cache):
        calls = {"n": 0}

        def producer():
            calls["n"] += 1
            return {"data": "expensive"}

        r1 = temp_cache.get_or_set("search", {"q": "ropa"}, producer)
        r2 = temp_cache.get_or_set("search", {"q": "ropa"}, producer)
        assert calls["n"] == 1
        assert r1["_cache"] == "miss"
        assert r2["_cache"] == "hit"

    def test_ttl_expiry(self, temp_cache):
        key = temp_cache.make_key("x", {"a": 1})
        temp_cache.set(key, {"v": 1}, ttl=1, namespace="x")
        assert temp_cache.get(key) is not None
        time.sleep(1.1)
        assert temp_cache.get(key) is None

    def test_different_payload_different_key(self, temp_cache):
        k1 = temp_cache.make_key("s", {"q": "a"})
        k2 = temp_cache.make_key("s", {"q": "b"})
        assert k1 != k2

    def test_clear_namespace(self, temp_cache):
        temp_cache.set(temp_cache.make_key("a", 1), {"v": 1}, namespace="a")
        temp_cache.set(temp_cache.make_key("b", 1), {"v": 1}, namespace="b")
        cleared = temp_cache.clear(namespace="a")
        assert cleared == 1
        assert temp_cache.stats()["total_entries"] == 1

    def test_purge_expired(self, temp_cache):
        temp_cache.set(temp_cache.make_key("a", 1), {"v": 1}, ttl=1, namespace="a")
        time.sleep(1.1)
        purged = temp_cache.purge_expired()
        assert purged == 1

    def test_stats_structure(self, temp_cache):
        temp_cache.set(temp_cache.make_key("s", 1), {"v": 1}, namespace="search")
        st = temp_cache.stats()
        assert st["total_entries"] == 1
        assert "search" in st["by_namespace"]


# ---------------- Search backends: retry + fallback signal ----------------

class TestSearchRobustness:
    def test_five_backends_registered(self):
        from src.sources.search_backends import SearchBackendManager
        m = SearchBackendManager()
        names = [b.name for b in m.backends]
        assert "ddg" in names and "ddg_lite" in names
        assert len(m.backends) >= 5

    def test_backend_has_retry_config(self):
        from src.sources.search_backends import DuckDuckGoBackend
        b = DuckDuckGoBackend()
        assert b.max_retries >= 1

    def test_ddg_filters_ads(self):
        # El parser de DDG debe descartar anuncios y.js/ad_domain
        from src.sources.search_backends import DuckDuckGoBackend
        b = DuckDuckGoBackend()
        html = (
            '<a class="result__a" href="https://duckduckgo.com/y.js?ad_domain=amazon.com">Ad</a>'
            '<a class="result__a" href="https://tiendareal.com.mx/">Tienda Real</a>'
        )
        b._do_search = lambda q, l, c: _parse_ddg(b, html, l)
        # Como _do_search está mockeado arriba con un helper, validamos vía regex directa:
        import re
        urls = []
        for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"', html):
            href = m.group(1).lower()
            if "y.js" in href or "ad_domain=" in href:
                continue
            urls.append(href)
        assert urls == ["https://tiendareal.com.mx/"]

    def test_search_dorks_tool_signals_fallback_when_exhausted(self, monkeypatch):
        import src.sources.search_backends as sb
        import src.skill.mcp_server as m
        from src.core.cache import get_cache
        get_cache().clear()
        mgr = sb.get_default_manager()
        monkeypatch.setattr(mgr, "available_backends", lambda: [])
        out = m._tool_search_dorks({"query": "zzz_imposible_query", "limit": 5})
        assert out["count"] == 0
        assert out["all_backends_exhausted"] is True
        assert out["web_search_fallback_allowed"] is True


def _parse_ddg(backend, html, limit):
    return []


# ---------------- user_paths: carpetas amigables para exportar ----------------

class TestUserPaths:
    def test_resolve_known_choices(self):
        from src.core.user_paths import resolve_output_dir, LEADS_SUBFOLDER
        for ch in ("escritorio", "descargas", "documentos", None, "default"):
            p = resolve_output_dir(ch)
            assert p is not None

    def test_resolve_explicit_path(self):
        from src.core.user_paths import resolve_output_dir
        p = resolve_output_dir("/tmp/mis_leads_xyz")
        assert str(p) == "/tmp/mis_leads_xyz"

    def test_resolve_project_output(self):
        from src.core.user_paths import resolve_output_dir
        assert str(resolve_output_dir("aqui")) == "output"

    def test_default_leads_dir_has_subfolder(self):
        from src.core.user_paths import default_leads_dir, LEADS_SUBFOLDER
        assert default_leads_dir().name == LEADS_SUBFOLDER

    def test_describe_location_returns_text(self):
        from src.core.user_paths import describe_location
        from pathlib import Path
        txt = describe_location(Path.home() / "Desktop" / "Leads-Fenix")
        assert isinstance(txt, str) and len(txt) > 0


class TestExportToFolder:
    def test_dispatcher_writes_to_custom_dir(self, tmp_path):
        from src.core.models import (RawRecord, ResearchPlan, PipelineState,
                                     ModeloNegocio, Canal, Estrategia)
        from src.agents.pipeline import agent_profiler, agent_dispatcher
        plan = ResearchPlan(nicho="ropa", zona="CDMX", modelo=ModeloNegocio.B2C,
                            canal=Canal.WEB, estrategia=Estrategia.QUICK, meta=3)
        st = PipelineState(plan=plan)
        st.candidatos = [RawRecord(source="denue", empresa="Test SA",
                                   telefono="+525512345678", estado="CDMX")]
        st = agent_profiler(st)
        st = agent_dispatcher(st, formats=["csv"], output_dir=str(tmp_path))
        csv_files = list(tmp_path.glob("*.csv"))
        assert len(csv_files) == 1
        assert st.exports["folder"] == str(tmp_path.resolve())
