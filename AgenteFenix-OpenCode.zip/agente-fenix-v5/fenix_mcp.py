#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fénix MCP — Lanzador AUTO-INSTALABLE (zero-config, zero-install).

Este es el ÚNICO archivo que opencode / Claude Code / Cursor necesitan ejecutar
para usar Agente Fénix como servidor MCP.

Cómo funciona (mágico para el usuario):
  • La PRIMERA vez que arranca, detecta si faltan dependencias y las instala SOLO
    (en un entorno aislado .fenix-venv dentro del proyecto). Tarda 1-3 min UNA vez.
  • Después relanza el servidor MCP real con esas dependencias.
  • Las siguientes veces arranca al instante (no reinstala nada).
  • Si no puede crear el venv, cae a `pip install --user` automáticamente.
  • NO requiere que el usuario corra pip, ni install.py, ni nada.

Config recomendada en opencode.json (ya incluida en este repo):
    "command": ["python3", "fenix_mcp.py"]     (Windows: "python")

El servidor MCP en sí es zero-deps para arrancar; solo las herramientas pesadas
(fenix_run, verify_email, etc.) necesitan las librerías, por eso las dejamos listas.
"""
from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".fenix-venv"
MARKER = VENV / ".fenix-deps-ok"

# import_name -> pip_package  (debe coincidir con requirements.txt Tier 0+1)
REQUIRED = {
    "requests": "requests",
    "bs4": "beautifulsoup4",
    "lxml": "lxml",
    "phonenumbers": "phonenumbers",
    "dns": "dnspython",
    "email_validator": "email-validator",
    "tenacity": "tenacity",
    "trafilatura": "trafilatura",
    "pytrends": "pytrends",
    "yaml": "pyyaml",
}


def log(msg: str) -> None:
    # SIEMPRE a stderr: stdout está reservado para el protocolo JSON-RPC del MCP.
    print(f"[fenix-launch] {msg}", file=sys.stderr, flush=True)


def venv_python(venv: Path) -> Path:
    if os.name == "nt":
        return venv / "Scripts" / "python.exe"
    return venv / "bin" / "python"


def _missing_for_interpreter(py: str) -> list[str]:
    """Módulos de REQUIRED que NO se pueden importar con el Python dado."""
    mods = list(REQUIRED)
    code = (
        "import importlib.util as u;"
        "mods=" + repr(mods) + ";"
        "print('\\n'.join(m for m in mods if u.find_spec(m) is None))"
    )
    try:
        r = subprocess.run([py, "-c", code], capture_output=True, text=True, timeout=60)
    except Exception:
        return mods
    return [l.strip() for l in (r.stdout or "").splitlines() if l.strip()]


def _missing_here() -> list[str]:
    """Módulos de REQUIRED que faltan en ESTE intérprete."""
    return [m for m in REQUIRED if importlib.util.find_spec(m) is None]


def _run_server_in_process() -> None:
    """Corre el servidor MCP en este mismo proceso (deps ya disponibles)."""
    os.chdir(ROOT)
    sys.path.insert(0, str(ROOT))
    from src.skill.mcp_server import serve  # noqa: E402
    sys.exit(serve())


def _exec_with(py: str) -> None:
    """Relanza el servidor MCP usando otro intérprete (el del venv)."""
    env = dict(os.environ)
    env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    env["FENIX_BOOTSTRAPPED"] = "1"  # guard anti-bucle
    os.chdir(ROOT)
    log("Iniciando servidor MCP con entorno preparado…")
    os.execve(py, [py, "-m", "src.skill.mcp_server"], env)


def _install_py_venv() -> str | None:
    """Reusa el .venv que crea install.py (si existe y tiene las deps)."""
    alt = ROOT / ".venv"
    apy = venv_python(alt)
    if apy.exists() and not _missing_for_interpreter(str(apy)):
        return str(apy)
    return None


def _ensure_venv() -> str | None:
    """Crea/repara el venv con las deps. Devuelve el python del venv, o None si falla."""
    # 1) Reusar el .venv de install.py si ya está listo (evita venv duplicado).
    alt = _install_py_venv()
    if alt:
        return alt

    vpy = venv_python(VENV)

    # Atajo rápido: marcador presente y python existe -> confiar.
    if MARKER.exists() and vpy.exists():
        return str(vpy)

    # Si el venv existe y ya tiene todo, marcar y usar.
    if vpy.exists() and not _missing_for_interpreter(str(vpy)):
        try:
            MARKER.write_text("ok", encoding="utf-8")
        except Exception:
            pass
        return str(vpy)

    log("Primera vez: preparando el entorno de Fénix (1-3 min). No cierres opencode…")
    try:
        subprocess.run(
            [sys.executable, "-m", "venv", str(VENV)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT, timeout=180,
        )
    except Exception as e:  # noqa: BLE001
        log(f"No pude crear el entorno virtual ({e}). Intentaré con --user.")
        return None

    vpy = venv_python(VENV)
    pip = [str(vpy), "-m", "pip", "install", "--no-cache-dir", "--disable-pip-version-check"]
    subprocess.run(pip + ["--upgrade", "pip"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    req = ROOT / "requirements.txt"
    if req.exists():
        subprocess.run(pip + ["-r", str(req)], stdout=sys.stderr, stderr=sys.stderr)

    missing = _missing_for_interpreter(str(vpy))
    if missing:
        pkgs = sorted({REQUIRED[m] for m in missing if m in REQUIRED})
        log(f"Reparando módulos faltantes: {', '.join(pkgs)}")
        subprocess.run(pip + pkgs, stdout=sys.stderr, stderr=sys.stderr)
        missing = _missing_for_interpreter(str(vpy))

    if not missing:
        try:
            MARKER.write_text("ok", encoding="utf-8")
        except Exception:
            pass
        log("Entorno listo ✓")
        return str(vpy)

    log(f"Aún faltan módulos en el venv: {', '.join(missing)}")
    return str(vpy)


def _pip_user_install() -> None:
    log("Instalando dependencias con pip --user (sin venv)…")
    pip = [sys.executable, "-m", "pip", "install", "--no-cache-dir",
           "--user", "--disable-pip-version-check"]
    req = ROOT / "requirements.txt"
    if req.exists():
        subprocess.run(pip + ["-r", str(req)], stdout=sys.stderr, stderr=sys.stderr)


def _ensure_env_file() -> None:
    """Crea .env desde .env.example si no existe (para que el usuario solo edite el token)."""
    env = ROOT / ".env"
    example = ROOT / ".env.example"
    if not env.exists() and example.exists():
        try:
            env.write_text(example.read_text(encoding="utf-8"), encoding="utf-8")
            log("Creé .env (rellena DENUE_TOKEN para datos reales de DENUE/INEGI).")
        except Exception:
            pass


def main() -> None:
    _ensure_env_file()
    # Si ya nos relanzaron (guard), corre directo y no vuelvas a bootstrap.
    if os.environ.get("FENIX_BOOTSTRAPPED") == "1":
        _run_server_in_process()
        return

    # ¿Este intérprete ya tiene TODO? -> arranca directo, sin tocar nada.
    if not _missing_here():
        _run_server_in_process()
        return

    # Faltan deps: preparar entorno aislado.
    vpy = _ensure_venv()
    if vpy and not _missing_for_interpreter(vpy):
        _exec_with(vpy)
        return

    # Fallback final: instalar en el intérprete actual con --user.
    _pip_user_install()
    if not _missing_here():
        _run_server_in_process()
        return

    # No se pudo instalar (sin internet / permisos). Arranca igual: el server
    # boota y solo las herramientas pesadas avisarán que falta una librería.
    log("No pude instalar todas las dependencias automáticamente.")
    log("Revisa tu conexión a internet y reabre opencode; el lanzador se auto-repara.")
    _run_server_in_process()


if __name__ == "__main__":
    main()
