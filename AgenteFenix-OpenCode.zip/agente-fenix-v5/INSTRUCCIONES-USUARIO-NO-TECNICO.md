# 🔥 Agente Fénix — Guía rápida (para cualquier persona)

> Solo sigues estos pasos **una vez**. No hay que saber programar.
> Tiempo total: ~10 minutos (la mayoría es esperar descargas).

---

## ✅ PASO 1 — Tener Python instalado (solo una vez en tu vida)

El Agente necesita un programa gratuito llamado **Python**. Revisa si ya lo tienes:

**Windows:**
1. Presiona la tecla ⊞ Windows, escribe `cmd` y abre **Símbolo del sistema**.
2. Escribe esto y presiona Enter:  `python --version`
3. Si ves algo como `Python 3.10` o mayor → ✅ ya lo tienes, pasa al PASO 2.
4. Si dice "no se reconoce" o abre una tienda → instálalo:
   - Entra a **https://www.python.org/downloads/**
   - Descarga el botón grande amarillo.
   - Al instalar, **MUY IMPORTANTE**: marca la casilla
     ☑ **"Add Python to PATH"** abajo, antes de darle "Install Now".

**Mac:**
1. Abre **Terminal** (lupa 🔍 arriba a la derecha, escribe "Terminal").
2. Escribe y Enter:  `python3 --version`
3. Si ves `Python 3.10` o mayor → ✅ listo. Si no, descárgalo de python.org.

---

## ✅ PASO 2 — Descomprimir el ZIP

1. Busca el archivo **`AgenteFenix-OpenCode.zip`** que te pasaron (normalmente en Descargas).
2. **Windows:** clic derecho sobre el ZIP → **Extraer todo** → **Extraer**.
   **Mac:** doble clic sobre el ZIP (se descomprime solo).
3. Te queda una carpeta llamada **`agente-fenix-v5`**. Ábrela.

---

## ✅ PASO 3 — Instalar con DOBLE CLIC (esta es la forma recomendada ⭐)

Dentro de la carpeta `agente-fenix-v5` busca el instalador y haz **doble clic**:

- **Windows:** doble clic en **`INSTALAR-WINDOWS.bat`**
  - Si Windows muestra una advertencia azul ("Windows protegió tu PC"), haz clic en
    **"Más información"** → **"Ejecutar de todas formas"**. Es normal con cualquier
    archivo descargado.
- **Mac / Linux:** doble clic en **`INSTALAR-MAC-LINUX.command`**
  - Si Mac dice que no se puede abrir, haz **clic derecho** sobre el archivo →
    **Abrir** → **Abrir**.

Se abrirá una ventana negra que instala todo **solo**. La primera vez tarda 1-3 min.
**No la cierres** hasta que diga **"TODO LISTO"**.

> ✨ **¿Por qué esta forma es la mejor?** El instalador copia el Agente *dentro* de
> OpenCode. Así, **aunque borres la carpeta que descargaste, el Agente sigue
> funcionando**. No tienes que cuidar dónde quedó la carpeta.

---

## ✅ PASO 4 — Usarlo en OpenCode

1. Abre **OpenCode** (si ya estaba abierto, **ciérralo y vuélvelo a abrir**).
2. Escribe en el chat el comando `/skills` → verás **`agente-fenix`**.
3. O simplemente pídele en español normal, por ejemplo:
   ```
   corre fenix para 5 leads de ropa en CDMX
   ```
4. ¡Listo! Te dará una lista de empresas. 🎉

> Funciona desde **cualquier carpeta** de OpenCode, no solo donde lo instalaste.

---

## ✅ PASO 5 (opcional) — Tu token para conseguir MUCHOS leads

Para conseguir **muchos** leads reales conviene un código gratis del gobierno (INEGI/DENUE).

- **Si ya tienes el token:** pégalo en el chat así:
  ```
  este es mi token DENUE: AQUI_PEGAS_TU_TOKEN
  ```
  El Agente lo guarda solo. No lo comparte con nadie.
- **Si no lo tienes:** pídele al Agente `cómo saco mi token DENUE` y te guía.

Sin token igual funciona, solo que con menos cantidad de empresas.

---

## 🗣️ Cómo pedirle cosas (copia y pega)

```
corre fenix para 50 leads de calzado en Guadalajara
busca tiendas de ropa en TikTok en Monterrey
necesito 100 mil leads de ecommerce en todo México
verifica el teléfono 5512345678
qué eventos comerciales hay activos hoy
exporta los mejores leads para HubSpot
```

> Para pedidos grandes (miles o +100 mil), el Agente lo hace **por bloques**
> automáticamente, sin duplicados y guardando el avance. Solo pídeselo y di que sí.

---

## 🆘 Si algo sale mal

| Problema | Solución |
|---|---|
| El doble clic no hace nada | Asegúrate de **extraer** el ZIP primero (no abrirlo "por dentro"). |
| "Windows protegió tu PC" | "Más información" → "Ejecutar de todas formas". |
| Mac: "no se puede abrir" | Clic derecho → Abrir → Abrir. |
| "Falta Python" | Repite el PASO 1 (en Windows marca "Add Python to PATH"). |
| OpenCode no muestra el agente | Ciérralo y reábrelo una vez. |
| Salen pocas empresas | Te falta el token DENUE → PASO 5. |
| Borré la carpeta y temo romper algo | Tranquilo: el Agente vive **dentro de OpenCode**, sigue funcionando. |

---

### En resumen
**1)** Instala Python · **2)** Descomprime el ZIP · **3)** Doble clic en
`INSTALAR-WINDOWS.bat` (o `INSTALAR-MAC-LINUX.command`) · **4)** Abre OpenCode y
escribe *"corre fenix para 5 leads de ropa en CDMX"*.

Aunque borres la carpeta, **el Agente sigue vivo dentro de OpenCode**. 🔥
