# 🔥 Agente Fénix — Empieza aquí (para usuarios sin experiencia)

Genera **leads reales de empresas mexicanas** para Skydropx desde **opencode**, sin
instalar nada a mano. Solo necesitas 2 archivos que ya vienen en esta carpeta:

- `fenix_mcp.py` → el **MCP** (motor de datos, se auto-instala solo).
- `SKILL.md` → la **skill** (el cerebro/persona del Agente Fénix).

---

## ✅ Forma RECOMENDADA: doble clic (a prueba de borrado) ⭐

Haz **doble clic** en el instalador que viene en esta carpeta:
- **Windows:** `INSTALAR-WINDOWS.bat`
- **Mac / Linux:** `INSTALAR-MAC-LINUX.command`

Instala todo solo y **copia el Agente DENTRO de opencode**, de modo que **aunque
borres esta carpeta, el MCP y la skill siguen funcionando**. La primera vez tarda
1-3 min; espera hasta "TODO LISTO". Luego abre opencode (ciérralo y reábrelo si ya
estaba abierto) y usa `/skills` → **agente-fenix**, o escribe
"corre fenix para 50 leads de ropa en CDMX".

> Esta es la mejor opción para usuarios no técnicos: no hay que cuidar dónde quedó
> la carpeta. Ver guía paso a paso en `INSTRUCCIONES-USUARIO-NO-TECNICO.md`.

---

## 🅱️ Alternativa: abrir la carpeta directamente en opencode

Si prefieres no instalar nada, abre **opencode** dentro de esta carpeta. Ya trae
`opencode.json` y `.opencode/skills/` preconfigurados, y `fenix_mcp.py` se auto-instala
la primera vez. **Pero ojo:** con este método, si borras o mueves la carpeta, deja de
funcionar. Para que sea a prueba de borrado, usa el doble clic de arriba.

---

## 💬 Forma alternativa: decirle a opencode "instala el mcp y el skill"

Si abriste opencode en **otra** carpeta, o prefieres que lo haga el asistente, copia
esta carpeta donde quieras y dile a opencode, en lenguaje natural:

> instala el mcp y el skill del agente fénix que están en esta carpeta

opencode leerá `AGENTS.md` (en esta misma carpeta) y hará el registro por ti. No hace
falta correr `pip` ni comandos: el MCP instala sus dependencias automáticamente la
primera vez que se usa.

---

## 🔑 Para datos masivos: tu token DENUE (gratis)

Para llegar a **+100,000 leads** conviene el token gratuito de INEGI/DENUE:

- Si **ya lo tienes**, solo pégalo en el chat y dile a Fénix:
  > este es mi token DENUE: TU_TOKEN

  Él lo guarda solo en `.env` (no lo comparte ni lo sube a internet).
- Si **no lo tienes**: sácalo gratis en **inegi.org.mx → API DENUE → registrarte**.
- Sin token igual funciona (con fuentes gratuitas), pero con menos volumen.

---

## 📈 ¿Cómo pido +100,000 leads?

Solo pídelo en lenguaje natural, por ejemplo:

> necesito 100 mil leads de ecommerce en todo México

Fénix lo hará **por bloques de 5,000** que se acumulan en la misma base **sin
duplicados** y con **guardado automático** (si algo se corta, retoma sin perder nada).
No necesitas instalar nada extra para llegar a esa cifra.

---

## 🆘 Si algo no arranca

- Asegúrate de tener **Python 3.10+** instalado (escribe `python3 --version`).
- Reabre opencode una vez (para que detecte el MCP).
- El lanzador `fenix_mcp.py` se **auto-repara**: si faltó internet, vuelve a intentarlo
  solo la próxima vez que uses una herramienta.
- Más detalle técnico en `README.md` y `docs/INSTALL.md`.
